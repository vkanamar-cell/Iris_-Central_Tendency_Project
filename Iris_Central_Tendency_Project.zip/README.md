# Iris Central Tendency Project

This project uses the Iris dataset to calculate measures of central tendency.

## Measures calculated
- Mean
- Median
- Mode

## Files
- `Iris.csv` - Iris dataset
- `central_tendency.py` - Python program

## How to run

```bash
python central_tendency.py
```
